<section class="footer">

   <p class="credit"> &copy; copyright  @ <?php echo date('Y'); ?> by <span>Christan Jay Español</span> </p>

</section>